# Phase 06 — Academic Structure

Build:
- academic years
- classes/grades
- divisions/sections
- subjects
- curriculum references
- teacher assignments
- student enrollment
- transfers

Rules:
- prevent invalid enrollment
- prevent conflicting assignments
- preserve history
- enforce academic-year boundaries
- enforce tenant/school scope
- support future academic years

Create APIs and admin UI.
Add validation and audit events.
