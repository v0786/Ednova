# Phase 00 — Product Discovery & Scope

Goal: turn the EDNOVA concept into an implementation-ready product definition.

Tasks:
- Inspect all existing EDNOVA documentation.
- Separate CURRENT, NEXT, and FUTURE functionality.
- Explicitly mark LMS as FUTURE/OUT OF CURRENT SCOPE.
- Define school types and institutional boundaries.
- Define primary personas: platform admin, school admin, principal, teacher, student, parent/guardian, security staff.
- Define core workflows.
- Identify dependencies between modules.
- Identify ambiguous requirements and convert them into decisions/TBDs.
- Create a phased roadmap.
- Define MVP acceptance criteria.

Deliverables:
- product scope
- personas
- module map
- dependency map
- prioritized backlog
- MVP definition
- out-of-scope list
- risk register

Do not write application code yet.
