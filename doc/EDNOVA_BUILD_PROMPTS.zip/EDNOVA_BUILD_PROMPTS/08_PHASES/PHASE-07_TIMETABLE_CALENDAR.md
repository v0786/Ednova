# Phase 07 — Timetable & Calendar

Build timetable and academic calendar management.

Features:
- periods
- timetable entries
- teacher assignment
- class/division assignment
- subject
- room/resource placeholder
- school events
- holidays
- substitutions
- cancellations
- publication

Conflict detection:
- teacher
- class/division
- room/resource where implemented

Users should see only authorized schedules.

Add timezone-aware date/time handling and tests for conflicts and schedule changes.
