# Phase 02 — Database & Domain Model

Design EDNOVA's canonical domain model.

Core entities should cover:
- tenant
- school
- academic_year
- term/period
- user
- role
- permission
- staff
- student
- guardian
- relationships
- class
- division/section
- subject
- teacher assignment
- enrollment
- timetable
- calendar event
- attendance
- daily academic record
- homework/work item
- announcement
- notification
- security gate event
- audit event

Requirements:
- UUID or equivalent stable identifiers
- created/updated timestamps
- soft deletion where appropriate
- tenant keys
- foreign-key integrity
- unique constraints
- indexes based on real queries
- historical records
- optimistic concurrency where needed
- migration strategy

Output:
1. ERD
2. entity definitions
3. relationships
4. constraints
5. indexes
6. migration plan
7. seed data strategy

Do not introduce LMS entities as current core entities.
