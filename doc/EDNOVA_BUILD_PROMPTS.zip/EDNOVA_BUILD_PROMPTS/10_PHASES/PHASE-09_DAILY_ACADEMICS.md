# Phase 09 — Daily Academics

Build the daily academic planning and record layer.

Teachers can:
- select authorized class/division/subject
- record today's topic
- lesson summary
- concepts
- textbook pages
- homework
- attachments/resources
- visibility
- publish/unpublish

Students/parents see only authorized records.

The objective is operational academic planning and documentation, NOT LMS functionality.
Do not implement courses, mastery engines, or learning marketplaces.
