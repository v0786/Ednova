# Phase 15 — Mobile Operational Experience

Design/build the mobile experience for high-frequency users.

Priority users:
- teachers
- security staff
- school administrators

Priority workflows:
- attendance
- timetable
- daily academic entry
- notifications
- student lookup
- security gate actions

Requirements:
- fast startup
- low interaction count
- reliable network retry
- clear offline/error states
- device permission minimization
- secure session handling
