# Phase 14 — Web Application UX

Build the EDNOVA web application.

UX principles:
- simple school workflows
- responsive
- mobile/tablet friendly
- fast navigation
- role-specific dashboards
- accessible forms/tables
- clear school context
- safe destructive actions
- clear status indicators

Build:
- authentication
- onboarding
- dashboards
- people
- academics
- timetable
- attendance
- communication
- reports
- security gate

Do not create LMS screens in the current product.
Use reusable components and consistent information architecture.
