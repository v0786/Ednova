# EDNOVA Phase Completion Prompt

Before declaring an EDNOVA phase complete, verify:

[ ] Scope implemented
[ ] Requirements traced
[ ] Database migrations complete
[ ] APIs implemented
[ ] Authorization tested
[ ] Tenant isolation tested
[ ] UI workflow complete where applicable
[ ] Error states handled
[ ] Audit events implemented
[ ] Unit tests pass
[ ] Integration tests pass
[ ] E2E tests pass where applicable
[ ] Type checking passes
[ ] Lint passes
[ ] Build passes
[ ] Documentation updated
[ ] No accidental LMS scope added
[ ] No known critical security issues

Produce:
1. completed work
2. verification results
3. files changed
4. migrations
5. known limitations
6. next recommended phase
