# EDNOVA Build Prompt Pack

This pack turns the EDNOVA concept into an implementation roadmap.

## Phase order

00 Discovery & Scope
01 Architecture
02 Database & Domain Model
03 Authentication / RBAC / Security
04 School Setup
05 People & Student Management
06 Academic Structure
07 Timetable & Calendar
08 Attendance
09 Daily Academics
10 Communication
11 Reporting
12 Security Gate
13 API & Integrations
14 Frontend UX
15 Mobile Experience
16 QA / Security / Reliability
17 Production Deployment
18 Future LMS (do not implement now)

## Agent prompts

- Autonomous implementation prompt
- Code review prompt
- Phase completion gate

## Important

EDNOVA is currently a school planning, management, and operations platform.
LMS is explicitly future scope.
