# Phase 04 — School Setup & Administration

Build the foundation for onboarding a school.

Features:
- create school
- school profile
- branding
- academic year
- terms
- holidays
- working days
- grading/configuration placeholders
- school settings
- administrative users
- school status
- audit trail

Workflow:
Platform Admin creates tenant/school
→ School Admin account
→ school configuration
→ academic year
→ initial structure
→ ready state

Include validation, permissions, audit events, and setup completion state.
