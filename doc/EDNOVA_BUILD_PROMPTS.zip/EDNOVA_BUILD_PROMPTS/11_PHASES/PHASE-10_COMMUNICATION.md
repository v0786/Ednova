# Phase 10 — Communication & Notifications

Build controlled school communication.

Features:
- announcements
- targeted messages
- teacher-parent communication
- notification preferences
- in-app notifications
- email/SMS provider extension points
- delivery status
- read state where supported

Security:
- recipient scope validation
- relationship validation
- tenant isolation
- rate limits
- attachment validation
- audit send decisions
- idempotent delivery

Do not expose unrelated students, parents, or staff.
