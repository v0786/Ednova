# Phase 01 — System Architecture

Design the production architecture for EDNOVA.

Requirements:
- multi-tenant SaaS
- strict tenant isolation
- modular domain architecture
- API-first backend
- web frontend
- mobile-responsive UI
- secure authentication
- RBAC and permission scopes
- audit logging
- notifications
- file/document handling
- integration layer
- observability

Define:
- frontend architecture
- backend architecture
- database architecture
- cache strategy
- background jobs
- event strategy
- object storage
- authentication
- authorization
- audit architecture
- deployment architecture
- CI/CD
- environment strategy
- backup/recovery
- monitoring

Produce architecture diagrams in Mermaid where useful.

Do not add LMS services to the current architecture unless clearly marked as future extension points.
