# Phase 03 — Identity, RBAC & Security

Implement EDNOVA authentication and authorization.

Roles:
- Platform Admin
- School Admin
- Principal
- Teacher
- Student
- Parent/Guardian
- Security Staff

Requirements:
- secure login
- session/token management
- password reset
- optional MFA extension point
- RBAC
- permission scopes
- tenant isolation
- school isolation
- relationship-based access where needed
- server-side authorization
- rate limiting
- secure password storage
- CSRF/session protections as applicable
- security event logging
- audit trail

Important:
Never trust client-side role checks.
Every sensitive API operation must enforce authorization on the server.

Create authorization tests for cross-tenant and cross-school access.
