# Phase 13 — API & Integrations

Create EDNOVA's integration platform.

Requirements:
- versioned REST API or documented equivalent
- authentication
- scoped API keys/service accounts
- webhook support
- idempotency
- request signing where appropriate
- rate limiting
- audit
- API documentation
- integration health
- retries
- dead-letter handling for asynchronous events

Design adapters for:
- identity
- notifications
- security/gate systems
- future third-party school systems

Never hard-code an external provider directly into the core domain.
