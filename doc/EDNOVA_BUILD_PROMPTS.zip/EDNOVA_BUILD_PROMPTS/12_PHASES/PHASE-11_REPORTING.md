# Phase 11 — Reports & Dashboards

Build operational dashboards and reporting.

Dashboards:
- school overview
- attendance
- student counts
- staff counts
- academic activity
- communication
- security activity
- administrative workload

Reports:
- attendance
- enrollment
- student status
- class/division
- teacher assignment
- timetable
- academic activity
- security gate activity

Requirements:
- tenant/school scoping
- permission-aware data
- date filters
- export
- performance-safe queries
- audit for sensitive reports
