# Phase 16 — QA, Security & Reliability

Create comprehensive verification.

Test layers:
- unit
- integration
- API
- authorization
- database
- end-to-end
- UI
- performance
- security
- migration
- backup/restore

Mandatory security tests:
- cross-tenant access
- cross-school access
- privilege escalation
- IDOR
- unauthorized student access
- unauthorized parent access
- unauthorized staff access
- audit tampering
- duplicate requests
- stale updates

Create a release gate:
No phase is complete until its acceptance criteria and regression suite pass.
