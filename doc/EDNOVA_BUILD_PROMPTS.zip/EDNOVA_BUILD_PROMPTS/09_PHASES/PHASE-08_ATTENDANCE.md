# Phase 08 — Attendance

Build attendance as a reliable operational workflow.

Features:
- attendance windows
- roster loading
- present
- absent
- late
- half-day
- excused
- quick mark-all
- correction request
- approval/rejection
- parent notification
- attendance reports

Rules:
- server-side roster authorization
- duplicate prevention
- idempotent writes
- correction history
- never silently overwrite historical attendance
- audit every correction

Optimize the UI for fast teacher use on mobile/tablet.
