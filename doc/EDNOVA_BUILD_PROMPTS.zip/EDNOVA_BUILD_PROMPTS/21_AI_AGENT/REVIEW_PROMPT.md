# EDNOVA Code Review Prompt

Review the current EDNOVA implementation as a senior architect and security engineer.

Check:
- architecture
- domain boundaries
- tenant isolation
- authorization
- data integrity
- migrations
- API contracts
- error handling
- concurrency
- auditability
- privacy
- performance
- accessibility
- test coverage
- maintainability

Classify findings:
CRITICAL / HIGH / MEDIUM / LOW.

For each finding:
- file
- location
- problem
- impact
- recommended fix
- test needed

Do not rewrite working code unnecessarily.
Do not introduce new product scope.
