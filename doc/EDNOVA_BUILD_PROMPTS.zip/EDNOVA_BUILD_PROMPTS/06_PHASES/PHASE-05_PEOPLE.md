# Phase 05 — People & Student Management

Build people management.

Student:
- identity
- contact information
- emergency contacts
- admission/enrollment
- student status
- documents
- academic history references

Staff:
- identity
- role
- department/assignment
- employment status
- school scope

Parent/Guardian:
- identity
- contact details
- relationship to student
- multiple guardians
- multiple children

Requirements:
- relationship integrity
- historical enrollment
- transfer handling
- deactivation
- import/export
- duplicate detection
- audit
- privacy-aware access

Create robust tests around guardian/student relationships and historical records.
