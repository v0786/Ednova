# EDNOVA Product Definition

## Product

EDNOVA is a general-purpose school planning, management, and operations platform.

## Current identity

EDNOVA is not currently an LMS.

## Primary objective

Give educational institutions a central system to plan, coordinate, execute, record, monitor, and audit school operations.

## Current core

- School administration
- Academic structure
- People management
- Student management
- Staff/teacher management
- Parent/guardian relationships
- Timetable and calendar
- Attendance
- Daily academics
- Communication
- Reports
- Security gate management
- Integrations
- Audit and security

## Future

LMS and advanced learning capabilities are future extensions.

## Product model

EDNOVA should support multiple schools/institutions through a multi-tenant architecture.

## Core design principle

A school should be able to answer:

What is planned?
Who is responsible?
When does it happen?
Who is affected?
What happened?
Was it authorized?
What needs attention next?

That is the core value of EDNOVA.
